# wxapp-aha-small-mall
第一个小程序项目，简单的商城项目
主要参考B站黑马程序员教学视频：https://www.bilibili.com/video/av73342655
本项目代码跟视频不完全一致，自己做了一些个人理解上的修改
比如：tab自定义组件，我的做法是只需传入标题名称，active状态都是组件内部管理